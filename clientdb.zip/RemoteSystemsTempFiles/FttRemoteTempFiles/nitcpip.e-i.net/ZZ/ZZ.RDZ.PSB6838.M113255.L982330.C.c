??=pragma filetag ("IBM-1147")
//
//
// ===========================================
// ===                                     ===
// ===   PSB6838     -     'TMC Cobol'     ===
// ===                                     ===
// ===   ----------------------------      ===
// ===   NE PAS MODIFIER CE SOURCE :       ===
// ===   TOUTE MODIFICATION DOIT ETRE      ===
// ===   EFFECTUEE PAR ZGEN                ===
// ===   ----------------------------      ===
// ===   DO NOT MODIFY THIS PROGRAM :      ===
// ===   UPDATES MUST BE MADE WITH         ===
// ===   THE ZGEN TOOL                     ===
// ===                                     ===
// ===========================================
// ===                                     ===
// ===   Generation  : 25/07/02 17:01:33   ===
// ===   By          : NNPRG4P             ===
// ===                                     ===
// ===========================================
//
//
// SKELS(ZTMCSPC0) - Update
//---------------------------------------------------------------------
// 29.08.2012*CJ* RUBIS 72776
//   - ADD __MQI_TRT_RAW                : Trait TMC avec msg MQ raw
// 26.03.2012*CJ*
//   - ADD __TMCPAL_SUP_NON       : Top TMCPAL avec param suppl.
//
// 10.02.2012*CJ*
//   - RPL filetag ("IBM-297") par filetag ("IBM-1147")
//   - RPL csect(CODE,"PSB6838")   : csect(CODE,"PSB6838c")
//   - RPL csect(STATIC,"psb6838") : csect(STATIC,"psb6838d")
//
//
// =========
// VARIABLES
// =========
#define __PSB_NUM         "6838"         // Numero Transaction
#pragma csect(CODE,       "PSB6838c" )  // Nom CSECT code
#pragma csect(STATIC,     "psb6838d" )  // Nom CSECT variable
#define __PSB_NBR_PCB     2         // Nbr PCB avec IOPCB+ALTPCB
#define __NBR_FCT         39         // Nbr fonctions
#define __MQI_TRT_NON             // Traitement MQ  : NON
#define __RMI_TRT_OUI             // TrT ref.RTG/LOC :OUI
#define __TMCPAL_SUP_NON          // Prm.suppl TMCPAL:NON
#define __TBL_PCB_NOM_NON         // TRT Table des noms PCB
#define __TRACEACTIVE_NON          // Pour trace active
#define __NIVEAUTRACE     0     // Niveau de trace = 0
// Definition  PSB
#define PSBNAME       "PSB"##__PSB_NUM##" "// Nom PSB
#define TSINAME       "TSI"##__PSB_NUM##" "// Code Transaction IMS
// -------------------------------------------------------------------
// MQQTSI : Nom queue MQ associee a la transaction SI et SSI
// -------------------------------------------------------------------
// - traitement messages en mode GBT (GBT utilise en mode mise a jour )
// - traitement de messages issus de MQ (MQ utilise pour transport)
// NB. si la transaction ne traite pas de msg GBT ou MQ :
//     il faut definir MQQTSI avec ""
// -------------------------------------------------------------------
#ifdef __MQI_TRT_NON                     // Traitement MQ : Non
 #define MQQTSI        ""
#endif
#ifdef __MQI_TRT_OUI                     // Traitement MQ : Oui
 #define MQQTSI        "QLO.TSI"__PSB_NUM".IMS.MOM"
#endif
#ifdef __MQI_TRT_CTX                     // Traitement MQ : Contexte
 #define MQQTSI        "QLO.TSI"__PSB_NUM".IMS.MOM.CTX"
#endif
#ifdef __MQI_TRT_RAW                     // Traitement MQ : RAW
 #define MQQTSI        "QLO.TSI"__PSB_NUM".IMS.RAW"
#endif
#ifdef __MQI_TRT_RWI                     // Traitement MQ : RWI
 #define MQQTSI        "QLO.TSI"__PSB_NUM".IMS.RAWINT"
#endif
// -------------------------------------------------------------------
// MQQGBT : Nom queue MQ GBT - Futur use
// -------------------------------------------------------------------
#define MQQGBT  ""
//
#pragma runopts  (ENV(IMS),PLIST(IMS))
#pragma linkage  (zcallpgm, OS)
#pragma map      (zcallpgm, "ZCALLPGM")
// ------------------------------------------------------------------
//  Include systeme
// ------------------------------------------------------------------
#include <ims.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <leawi.h>
#include <time.h>
// ------------------------------------------------------------------
//  Include Moteur TMC + include SAS
// ------------------------------------------------------------------
// #include "GTOàLTOA.H"                // Include conversion itoa
#include "mtrcimsc.h"                   // Include moteur TMC par call
#include "htmcifc.h"
// ------------------------------------------------------------------
//  Definitions bases IMS : table PCB
// ------------------------------------------------------------------
typedef struct {PCB_STRUCT(256)} DB_PCB_GEN ;
typedef struct
{
   int         nbr_pcb ;                     // Nombre PCB
   DB_PCB_GEN *ptr_pcb[__PSB_NBR_PCB];       // Table pointeur PCB
} ST_TBL_PCB ;
static ST_TBL_PCB tbl_pcb ;                  // Table PCB
//ADD*DEB*CJ/OL*26.03.2012*
#ifdef __TBL_PCB_NOM_OUI
typedef struct
{
   int         nbr_pcb ;                     // Nombre PCB
   ST_PCB_NOM  tbi_pcb_nom[__PSB_NBR_PCB];   // Table noms+ind PCBS
} ST_TBL_PCB_NOM ;
static ST_TBL_PCB_NOM tbl_pcb_nom ;
#endif
//ADD*FIN*CJ/OL*26.03.2012*
// Activation trace
#ifdef __TRACEACTIVE
 static int niv_trc = __NIVEAUTRACE ;
#endif
/*********************************************************************
 *                                                                   *
 *  Definitions specifiques metier                                   *
 *                                                                   *
 *********************************************************************/
// -------------------------------------------------------------------
//  Declaration des fonctions métier
// NB.Les differentes fonctions internes doivent etre déclarées.
// -------------------------------------------------------------------
static void S_D_PING();                 // Fonction PING
// -------------------------------------------------------------------
//  Definitions table automate - table service fonction
// -------------------------------------------------------------------
static struct Pfct TAB_fctmet[__NBR_FCT+1] =
{
    {
    //
    // Fonction
    //
        ETA_PTB_OCC,                  // Etat = Occupe
        "", 0,                        // SFO
        "",                    // SFD
        0,                      // Longueur SFD
                                        // Routage avant appel fct
        "",
        0,                    // Lng Routage avant appel fct
        "M",                          // Type fct = module
        (void *)NULL,                 // Ptr fct métier
        "",                  // Nom module métier
        "R",                  // Sens message après fct
        "N",                          // Obligation retour
        "",                  // Nouveau SFD
        0,                    // Longueur Nouveau SFD
        "",                  // Type de communication
        "",                  // Nom communication
        0,                    // Longueur nom communication
                                      // Paramètres communication
        "",
        0,                    // Lng param communication
        1,                            // Calcul intégrité
        1,                            // Calcul signature
        0,                            // Confidentialité
        0                             // Compression
    },
    {
    //
    // Fonction FCTE:COMPTEURS
    //
        ETA_PTB_OCC,                  // Etat = Occupe
        "", 0,                        // SFO
        "FCTE:COMPTEURS",                    // SFD
        14,                      // Longueur SFD
                                        // Routage avant appel fct
        "",
        0,                    // Lng Routage avant appel fct
        "M",                          // Type fct = module
        (void *)NULL,                 // Ptr fct métier
        "EIVTWE01",                  // Nom module métier
        "R",                  // Sens message après fct
        "N",                          // Obligation retour
        "",                  // Nouveau SFD
        0,                    // Longueur Nouveau SFD
        "",                  // Type de communication
        "",                  // Nom communication
        0,                    // Longueur nom communication
                                      // Paramètres communication
        "",
        0,                    // Lng param communication
        1,                            // Calcul intégrité
        1,                            // Calcul signature
        0,                            // Confidentialité
        0                             // Compression
    },
    {
    //
    // Fonction FCTE:CPI CLIFOU
    //
        ETA_PTB_OCC,                  // Etat = Occupe
        "", 0,                        // SFO
        "FCTE:CPI CLIFOU",                    // SFD
        15,                      // Longueur SFD
                                        // Routage avant appel fct
        "",
        0,                    // Lng Routage avant appel fct
        "M",                          // Type fct = module
        (void *)NULL,                 // Ptr fct métier
        "EIVTWE04",                  // Nom module métier
        "R",                  // Sens message après fct
        "N",                          // Obligation retour
        "",                  // Nouveau SFD
        0,                    // Longueur Nouveau SFD
        "",                  // Type de communication
        "",                  // Nom communication
        0,                    // Longueur nom communication
                                      // Paramètres communication
        "",
        0,                    // Lng param communication
        1,                            // Calcul intégrité
        1,                            // Calcul signature
        0,                            // Confidentialité
        0                             // Compression
    },
    {
    //
    // Fonction FCTE:DENOMI
    //
        ETA_PTB_OCC,                  // Etat = Occupe
        "", 0,                        // SFO
        "FCTE:DENOMI",                    // SFD
        11,                      // Longueur SFD
                                        // Routage avant appel fct
        "",
        0,                    // Lng Routage avant appel fct
        "M",                          // Type fct = module
        (void *)NULL,                 // Ptr fct métier
        "EIVTWE02",                  // Nom module métier
        "A",                  // Sens message après fct
        "N",                          // Obligation retour
        "FCTE:DENOMI II",                  // Nouveau SFD
        14,                    // Longueur Nouveau SFD
        "",                  // Type de communication
        "",                  // Nom communication
        0,                    // Longueur nom communication
                                      // Paramètres communication
        "",
        0,                    // Lng param communication
        1,                            // Calcul intégrité
        1,                            // Calcul signature
        0,                            // Confidentialité
        0                             // Compression
    },
    {
    //
    // Fonction FCTE:DENOMI II
    //
        ETA_PTB_OCC,                  // Etat = Occupe
        "", 0,                        // SFO
        "FCTE:DENOMI II",                    // SFD
        14,                      // Longueur SFD
                                        // Routage avant appel fct
        "",
        0,                    // Lng Routage avant appel fct
        "M",                          // Type fct = module
        (void *)NULL,                 // Ptr fct métier
        "EIVTWE02",                  // Nom module métier
        "R",                  // Sens message après fct
        "N",                          // Obligation retour
        "",                  // Nouveau SFD
        0,                    // Longueur Nouveau SFD
        "",                  // Type de communication
        "",                  // Nom communication
        0,                    // Longueur nom communication
                                      // Paramètres communication
        "",
        0,                    // Lng param communication
        1,                            // Calcul intégrité
        1,                            // Calcul signature
        0,                            // Confidentialité
        0                             // Compression
    },
    {
    //
    // Fonction FCTE:DEVIS CLI
    //
        ETA_PTB_OCC,                  // Etat = Occupe
        "", 0,                        // SFO
        "FCTE:DEVIS CLI",                    // SFD
        14,                      // Longueur SFD
                                        // Routage avant appel fct
        "",
        0,                    // Lng Routage avant appel fct
        "M",                          // Type fct = module
        (void *)NULL,                 // Ptr fct métier
        "EIVTWE21",                  // Nom module métier
        "R",                  // Sens message après fct
        "N",                          // Obligation retour
        "",                  // Nouveau SFD
        0,                    // Longueur Nouveau SFD
        "",                  // Type de communication
        "",                  // Nom communication
        0,                    // Longueur nom communication
                                      // Paramètres communication
        "",
        0,                    // Lng param communication
        1,                            // Calcul intégrité
        1,                            // Calcul signature
        0,                            // Confidentialité
        0                             // Compression
    },
    {
    //
    // Fonction FCTE:DONGEN
    //
        ETA_PTB_OCC,                  // Etat = Occupe
        "", 0,                        // SFO
        "FCTE:DONGEN",                    // SFD
        11,                      // Longueur SFD
                                        // Routage avant appel fct
        "",
        0,                    // Lng Routage avant appel fct
        "M",                          // Type fct = module
        (void *)NULL,                 // Ptr fct métier
        "EIVTWE22",                  // Nom module métier
        "R",                  // Sens message après fct
        "N",                          // Obligation retour
        "",                  // Nouveau SFD
        0,                    // Longueur Nouveau SFD
        "",                  // Type de communication
        "",                  // Nom communication
        0,                    // Longueur nom communication
                                      // Paramètres communication
        "",
        0,                    // Lng param communication
        1,                            // Calcul intégrité
        1,                            // Calcul signature
        0,                            // Confidentialité
        0                             // Compression
    },
    {
    //
    // Fonction FCTE:DOSSIER ABO
    //
        ETA_PTB_OCC,                  // Etat = Occupe
        "", 0,                        // SFO
        "FCTE:DOSSIER ABO",                    // SFD
        16,                      // Longueur SFD
                                        // Routage avant appel fct
        "",
        0,                    // Lng Routage avant appel fct
        "M",                          // Type fct = module
        (void *)NULL,                 // Ptr fct métier
        "EIVTWE02",                  // Nom module métier
        "R",                  // Sens message après fct
        "N",                          // Obligation retour
        "",                  // Nouveau SFD
        0,                    // Longueur Nouveau SFD
        "",                  // Type de communication
        "",                  // Nom communication
        0,                    // Longueur nom communication
                                      // Paramètres communication
        "",
        0,                    // Lng param communication
        1,                            // Calcul intégrité
        1,                            // Calcul signature
        0,                            // Confidentialité
        0                             // Compression
    },
    {
    //
    // Fonction FCTE:EPITHETE
    //
        ETA_PTB_OCC,                  // Etat = Occupe
        "", 0,                        // SFO
        "FCTE:EPITHETE",                    // SFD
        13,                      // Longueur SFD
                                        // Routage avant appel fct
        "",
        0,                    // Lng Routage avant appel fct
        "M",                          // Type fct = module
        (void *)NULL,                 // Ptr fct métier
        "EIVTWE17",                  // Nom module métier
        "R",                  // Sens message après fct
        "N",                          // Obligation retour
        "",                  // Nouveau SFD
        0,                    // Longueur Nouveau SFD
        "",                  // Type de communication
        "",                  // Nom communication
        0,                    // Longueur nom communication
                                      // Paramètres communication
        "",
        0,                    // Lng param communication
        1,                            // Calcul intégrité
        1,                            // Calcul signature
        0,                            // Confidentialité
        0                             // Compression
    },
    {
    //
    // Fonction FCTE:EVENEMENTS
    //
        ETA_PTB_OCC,                  // Etat = Occupe
        "", 0,                        // SFO
        "FCTE:EVENEMENTS",                    // SFD
        15,                      // Longueur SFD
                                        // Routage avant appel fct
        "",
        0,                    // Lng Routage avant appel fct
        "M",                          // Type fct = module
        (void *)NULL,                 // Ptr fct métier
        "EIVTWE23",                  // Nom module métier
        "R",                  // Sens message après fct
        "N",                          // Obligation retour
        "",                  // Nouveau SFD
        0,                    // Longueur Nouveau SFD
        "",                  // Type de communication
        "",                  // Nom communication
        0,                    // Longueur nom communication
                                      // Paramètres communication
        "",
        0,                    // Lng param communication
        1,                            // Calcul intégrité
        1,                            // Calcul signature
        0,                            // Confidentialité
        0                             // Compression
    },
    {
    //
    // Fonction FCTE:EXTERNE
    //
        ETA_PTB_OCC,                  // Etat = Occupe
        "", 0,                        // SFO
        "FCTE:EXTERNE",                    // SFD
        12,                      // Longueur SFD
                                        // Routage avant appel fct
        "",
        0,                    // Lng Routage avant appel fct
        "M",                          // Type fct = module
        (void *)NULL,                 // Ptr fct métier
        "EIVTWE29",                  // Nom module métier
        "R",                  // Sens message après fct
        "N",                          // Obligation retour
        "",                  // Nouveau SFD
        0,                    // Longueur Nouveau SFD
        "",                  // Type de communication
        "",                  // Nom communication
        0,                    // Longueur nom communication
                                      // Paramètres communication
        "",
        0,                    // Lng param communication
        1,                            // Calcul intégrité
        1,                            // Calcul signature
        0,                            // Confidentialité
        0                             // Compression
    },
    {
    //
    // Fonction FCTE:FTCFTF
    //
        ETA_PTB_OCC,                  // Etat = Occupe
        "", 0,                        // SFO
        "FCTE:FTCFTF",                    // SFD
        11,                      // Longueur SFD
                                        // Routage avant appel fct
        "",
        0,                    // Lng Routage avant appel fct
        "M",                          // Type fct = module
        (void *)NULL,                 // Ptr fct métier
        "EIVTWE26",                  // Nom module métier
        "R",                  // Sens message après fct
        "N",                          // Obligation retour
        "",                  // Nouveau SFD
        0,                    // Longueur Nouveau SFD
        "",                  // Type de communication
        "",                  // Nom communication
        0,                    // Longueur nom communication
                                      // Paramètres communication
        "",
        0,                    // Lng param communication
        1,                            // Calcul intégrité
        1,                            // Calcul signature
        0,                            // Confidentialité
        0                             // Compression
    },
    {
    //
    // Fonction FCTE:FTRCLI ART
    //
        ETA_PTB_OCC,                  // Etat = Occupe
        "", 0,                        // SFO
        "FCTE:FTRCLI ART",                    // SFD
        15,                      // Longueur SFD
                                        // Routage avant appel fct
        "",
        0,                    // Lng Routage avant appel fct
        "M",                          // Type fct = module
        (void *)NULL,                 // Ptr fct métier
        "EIVTWE10",                  // Nom module métier
        "R",                  // Sens message après fct
        "N",                          // Obligation retour
        "",                  // Nouveau SFD
        0,                    // Longueur Nouveau SFD
        "",                  // Type de communication
        "",                  // Nom communication
        0,                    // Longueur nom communication
                                      // Paramètres communication
        "",
        0,                    // Lng param communication
        1,                            // Calcul intégrité
        1,                            // Calcul signature
        0,                            // Confidentialité
        0                             // Compression
    },
    {
    //
    // Fonction FCTE:FTRCLI CPI
    //
        ETA_PTB_OCC,                  // Etat = Occupe
        "", 0,                        // SFO
        "FCTE:FTRCLI CPI",                    // SFD
        15,                      // Longueur SFD
                                        // Routage avant appel fct
        "",
        0,                    // Lng Routage avant appel fct
        "M",                          // Type fct = module
        (void *)NULL,                 // Ptr fct métier
        "EIVTWE12",                  // Nom module métier
        "R",                  // Sens message après fct
        "N",                          // Obligation retour
        "",                  // Nouveau SFD
        0,                    // Longueur Nouveau SFD
        "",                  // Type de communication
        "",                  // Nom communication
        0,                    // Longueur nom communication
                                      // Paramètres communication
        "",
        0,                    // Lng param communication
        1,                            // Calcul intégrité
        1,                            // Calcul signature
        0,                            // Confidentialité
        0                             // Compression
    },
    {
    //
    // Fonction FCTE:FTRCLI ECS
    //
        ETA_PTB_OCC,                  // Etat = Occupe
        "", 0,                        // SFO
        "FCTE:FTRCLI ECS",                    // SFD
        15,                      // Longueur SFD
                                        // Routage avant appel fct
        "",
        0,                    // Lng Routage avant appel fct
        "M",                          // Type fct = module
        (void *)NULL,                 // Ptr fct métier
        "EIVTWE13",                  // Nom module métier
        "R",                  // Sens message après fct
        "N",                          // Obligation retour
        "",                  // Nouveau SFD
        0,                    // Longueur Nouveau SFD
        "",                  // Type de communication
        "",                  // Nom communication
        0,                    // Longueur nom communication
                                      // Paramètres communication
        "",
        0,                    // Lng param communication
        1,                            // Calcul intégrité
        1,                            // Calcul signature
        0,                            // Confidentialité
        0                             // Compression
    },
    {
    //
    // Fonction FCTE:FTRCLI GEST
    //
        ETA_PTB_OCC,                  // Etat = Occupe
        "", 0,                        // SFO
        "FCTE:FTRCLI GEST",                    // SFD
        16,                      // Longueur SFD
                                        // Routage avant appel fct
        "",
        0,                    // Lng Routage avant appel fct
        "M",                          // Type fct = module
        (void *)NULL,                 // Ptr fct métier
        "EIVTWE11",                  // Nom module métier
        "R",                  // Sens message après fct
        "N",                          // Obligation retour
        "",                  // Nouveau SFD
        0,                    // Longueur Nouveau SFD
        "",                  // Type de communication
        "",                  // Nom communication
        0,                    // Longueur nom communication
                                      // Paramètres communication
        "",
        0,                    // Lng param communication
        1,                            // Calcul intégrité
        1,                            // Calcul signature
        0,                            // Confidentialité
        0                             // Compression
    },
    {
    //
    // Fonction FCTE:FTRCLI LIT
    //
        ETA_PTB_OCC,                  // Etat = Occupe
        "", 0,                        // SFO
        "FCTE:FTRCLI LIT",                    // SFD
        15,                      // Longueur SFD
                                        // Routage avant appel fct
        "",
        0,                    // Lng Routage avant appel fct
        "M",                          // Type fct = module
        (void *)NULL,                 // Ptr fct métier
        "EIVTWE14",                  // Nom module métier
        "R",                  // Sens message après fct
        "N",                          // Obligation retour
        "",                  // Nouveau SFD
        0,                    // Longueur Nouveau SFD
        "",                  // Type de communication
        "",                  // Nom communication
        0,                    // Longueur nom communication
                                      // Paramètres communication
        "",
        0,                    // Lng param communication
        1,                            // Calcul intégrité
        1,                            // Calcul signature
        0,                            // Confidentialité
        0                             // Compression
    },
    {
    //
    // Fonction FCTE:FTRFOU BAP
    //
        ETA_PTB_OCC,                  // Etat = Occupe
        "", 0,                        // SFO
        "FCTE:FTRFOU BAP",                    // SFD
        15,                      // Longueur SFD
                                        // Routage avant appel fct
        "",
        0,                    // Lng Routage avant appel fct
        "M",                          // Type fct = module
        (void *)NULL,                 // Ptr fct métier
        "EIVTWE07",                  // Nom module métier
        "R",                  // Sens message après fct
        "N",                          // Obligation retour
        "",                  // Nouveau SFD
        0,                    // Longueur Nouveau SFD
        "",                  // Type de communication
        "",                  // Nom communication
        0,                    // Longueur nom communication
                                      // Paramètres communication
        "",
        0,                    // Lng param communication
        1,                            // Calcul intégrité
        1,                            // Calcul signature
        0,                            // Confidentialité
        0                             // Compression
    },
    {
    //
    // Fonction FCTE:FTRFOU GEST
    //
        ETA_PTB_OCC,                  // Etat = Occupe
        "", 0,                        // SFO
        "FCTE:FTRFOU GEST",                    // SFD
        16,                      // Longueur SFD
                                        // Routage avant appel fct
        "",
        0,                    // Lng Routage avant appel fct
        "M",                          // Type fct = module
        (void *)NULL,                 // Ptr fct métier
        "EIVTWE09",                  // Nom module métier
        "R",                  // Sens message après fct
        "N",                          // Obligation retour
        "",                  // Nouveau SFD
        0,                    // Longueur Nouveau SFD
        "",                  // Type de communication
        "",                  // Nom communication
        0,                    // Longueur nom communication
                                      // Paramètres communication
        "",
        0,                    // Lng param communication
        1,                            // Calcul intégrité
        1,                            // Calcul signature
        0,                            // Confidentialité
        0                             // Compression
    },
    {
    //
    // Fonction FCTE:FTRFOU ING
    //
        ETA_PTB_OCC,                  // Etat = Occupe
        "", 0,                        // SFO
        "FCTE:FTRFOU ING",                    // SFD
        15,                      // Longueur SFD
                                        // Routage avant appel fct
        "",
        0,                    // Lng Routage avant appel fct
        "M",                          // Type fct = module
        (void *)NULL,                 // Ptr fct métier
        "EIVTWE06",                  // Nom module métier
        "R",                  // Sens message après fct
        "N",                          // Obligation retour
        "",                  // Nouveau SFD
        0,                    // Longueur Nouveau SFD
        "",                  // Type de communication
        "",                  // Nom communication
        0,                    // Longueur nom communication
                                      // Paramètres communication
        "",
        0,                    // Lng param communication
        1,                            // Calcul intégrité
        1,                            // Calcul signature
        0,                            // Confidentialité
        0                             // Compression
    },
    {
    //
    // Fonction FCTE:FTRFOU PAI
    //
        ETA_PTB_OCC,                  // Etat = Occupe
        "", 0,                        // SFO
        "FCTE:FTRFOU PAI",                    // SFD
        15,                      // Longueur SFD
                                        // Routage avant appel fct
        "",
        0,                    // Lng Routage avant appel fct
        "M",                          // Type fct = module
        (void *)NULL,                 // Ptr fct métier
        "EIVTWE08",                  // Nom module métier
        "R",                  // Sens message après fct
        "N",                          // Obligation retour
        "",                  // Nouveau SFD
        0,                    // Longueur Nouveau SFD
        "",                  // Type de communication
        "",                  // Nom communication
        0,                    // Longueur nom communication
                                      // Paramètres communication
        "",
        0,                    // Lng param communication
        1,                            // Calcul intégrité
        1,                            // Calcul signature
        0,                            // Confidentialité
        0                             // Compression
    },
    {
    //
    // Fonction FCTE:FTRFOU RCV
    //
        ETA_PTB_OCC,                  // Etat = Occupe
        "", 0,                        // SFO
        "FCTE:FTRFOU RCV",                    // SFD
        15,                      // Longueur SFD
                                        // Routage avant appel fct
        "",
        0,                    // Lng Routage avant appel fct
        "M",                          // Type fct = module
        (void *)NULL,                 // Ptr fct métier
        "EIVTWE05",                  // Nom module métier
        "R",                  // Sens message après fct
        "N",                          // Obligation retour
        "",                  // Nouveau SFD
        0,                    // Longueur Nouveau SFD
        "",                  // Type de communication
        "",                  // Nom communication
        0,                    // Longueur nom communication
                                      // Paramètres communication
        "",
        0,                    // Lng param communication
        1,                            // Calcul intégrité
        1,                            // Calcul signature
        0,                            // Confidentialité
        0                             // Compression
    },
    {
    //
    // Fonction FCTE:GROUPES
    //
        ETA_PTB_OCC,                  // Etat = Occupe
        "", 0,                        // SFO
        "FCTE:GROUPES",                    // SFD
        12,                      // Longueur SFD
                                        // Routage avant appel fct
        "",
        0,                    // Lng Routage avant appel fct
        "M",                          // Type fct = module
        (void *)NULL,                 // Ptr fct métier
        "EIVTWE03",                  // Nom module métier
        "R",                  // Sens message après fct
        "N",                          // Obligation retour
        "",                  // Nouveau SFD
        0,                    // Longueur Nouveau SFD
        "",                  // Type de communication
        "",                  // Nom communication
        0,                    // Longueur nom communication
                                      // Paramètres communication
        "",
        0,                    // Lng param communication
        1,                            // Calcul intégrité
        1,                            // Calcul signature
        0,                            // Confidentialité
        0                             // Compression
    },
    {
    //
    // Fonction FCTE:IFCLEC
    //
        ETA_PTB_OCC,                  // Etat = Occupe
        "", 0,                        // SFO
        "FCTE:IFCLEC",                    // SFD
        11,                      // Longueur SFD
                                        // Routage avant appel fct
        "",
        0,                    // Lng Routage avant appel fct
        "M",                          // Type fct = module
        (void *)NULL,                 // Ptr fct métier
        "EIVTWE24",                  // Nom module métier
        "R",                  // Sens message après fct
        "N",                          // Obligation retour
        "",                  // Nouveau SFD
        0,                    // Longueur Nouveau SFD
        "",                  // Type de communication
        "",                  // Nom communication
        0,                    // Longueur nom communication
                                      // Paramètres communication
        "",
        0,                    // Lng param communication
        1,                            // Calcul intégrité
        1,                            // Calcul signature
        0,                            // Confidentialité
        0                             // Compression
    },
    {
    //
    // Fonction FCTE:IFCMOD
    //
        ETA_PTB_OCC,                  // Etat = Occupe
        "", 0,                        // SFO
        "FCTE:IFCMOD",                    // SFD
        11,                      // Longueur SFD
                                        // Routage avant appel fct
        "",
        0,                    // Lng Routage avant appel fct
        "M",                          // Type fct = module
        (void *)NULL,                 // Ptr fct métier
        "EIVTWE25",                  // Nom module métier
        "R",                  // Sens message après fct
        "N",                          // Obligation retour
        "",                  // Nouveau SFD
        0,                    // Longueur Nouveau SFD
        "",                  // Type de communication
        "",                  // Nom communication
        0,                    // Longueur nom communication
                                      // Paramètres communication
        "",
        0,                    // Lng param communication
        1,                            // Calcul intégrité
        1,                            // Calcul signature
        0,                            // Confidentialité
        0                             // Compression
    },
    {
    //
    // Fonction FCTE:IMPORTS CPI
    //
        ETA_PTB_OCC,                  // Etat = Occupe
        "", 0,                        // SFO
        "FCTE:IMPORTS CPI",                    // SFD
        16,                      // Longueur SFD
                                        // Routage avant appel fct
        "",
        0,                    // Lng Routage avant appel fct
        "M",                          // Type fct = module
        (void *)NULL,                 // Ptr fct métier
        "EIVTWE18",                  // Nom module métier
        "R",                  // Sens message après fct
        "N",                          // Obligation retour
        "",                  // Nouveau SFD
        0,                    // Longueur Nouveau SFD
        "",                  // Type de communication
        "",                  // Nom communication
        0,                    // Longueur nom communication
                                      // Paramètres communication
        "",
        0,                    // Lng param communication
        1,                            // Calcul intégrité
        1,                            // Calcul signature
        0,                            // Confidentialité
        0                             // Compression
    },
    {
    //
    // Fonction FCTE:MAJBAD
    //
        ETA_PTB_OCC,                  // Etat = Occupe
        "", 0,                        // SFO
        "FCTE:MAJBAD",                    // SFD
        11,                      // Longueur SFD
                                        // Routage avant appel fct
        "",
        0,                    // Lng Routage avant appel fct
        "M",                          // Type fct = module
        (void *)NULL,                 // Ptr fct métier
        "EIVTWE02",                  // Nom module métier
        "R",                  // Sens message après fct
        "N",                          // Obligation retour
        "",                  // Nouveau SFD
        0,                    // Longueur Nouveau SFD
        "",                  // Type de communication
        "",                  // Nom communication
        0,                    // Longueur nom communication
                                      // Paramètres communication
        "",
        0,                    // Lng param communication
        1,                            // Calcul intégrité
        1,                            // Calcul signature
        0,                            // Confidentialité
        0                             // Compression
    },
    {
    //
    // Fonction FCTE:MASSE
    //
        ETA_PTB_OCC,                  // Etat = Occupe
        "", 0,                        // SFO
        "FCTE:MASSE",                    // SFD
        10,                      // Longueur SFD
                                        // Routage avant appel fct
        "",
        0,                    // Lng Routage avant appel fct
        "M",                          // Type fct = module
        (void *)NULL,                 // Ptr fct métier
        "EIVTWE28",                  // Nom module métier
        "R",                  // Sens message après fct
        "N",                          // Obligation retour
        "",                  // Nouveau SFD
        0,                    // Longueur Nouveau SFD
        "",                  // Type de communication
        "",                  // Nom communication
        0,                    // Longueur nom communication
                                      // Paramètres communication
        "",
        0,                    // Lng param communication
        1,                            // Calcul intégrité
        1,                            // Calcul signature
        0,                            // Confidentialité
        0                             // Compression
    },
    {
    //
    // Fonction FCTE:MEC
    //
        ETA_PTB_OCC,                  // Etat = Occupe
        "", 0,                        // SFO
        "FCTE:MEC",                    // SFD
        8,                      // Longueur SFD
                                        // Routage avant appel fct
        "",
        0,                    // Lng Routage avant appel fct
        "M",                          // Type fct = module
        (void *)NULL,                 // Ptr fct métier
        "EIVTWE15",                  // Nom module métier
        "R",                  // Sens message après fct
        "N",                          // Obligation retour
        "",                  // Nouveau SFD
        0,                    // Longueur Nouveau SFD
        "",                  // Type de communication
        "",                  // Nom communication
        0,                    // Longueur nom communication
                                      // Paramètres communication
        "",
        0,                    // Lng param communication
        1,                            // Calcul intégrité
        1,                            // Calcul signature
        0,                            // Confidentialité
        0                             // Compression
    },
    {
    //
    // Fonction FCTE:MECPIE
    //
        ETA_PTB_OCC,                  // Etat = Occupe
        "", 0,                        // SFO
        "FCTE:MECPIE",                    // SFD
        11,                      // Longueur SFD
                                        // Routage avant appel fct
        "",
        0,                    // Lng Routage avant appel fct
        "M",                          // Type fct = module
        (void *)NULL,                 // Ptr fct métier
        "EIVTWE16",                  // Nom module métier
        "R",                  // Sens message après fct
        "N",                          // Obligation retour
        "",                  // Nouveau SFD
        0,                    // Longueur Nouveau SFD
        "",                  // Type de communication
        "",                  // Nom communication
        0,                    // Longueur nom communication
                                      // Paramètres communication
        "",
        0,                    // Lng param communication
        1,                            // Calcul intégrité
        1,                            // Calcul signature
        0,                            // Confidentialité
        0                             // Compression
    },
    {
    //
    // Fonction FCTE:NOTIF
    //
        ETA_PTB_OCC,                  // Etat = Occupe
        "", 0,                        // SFO
        "FCTE:NOTIF",                    // SFD
        10,                      // Longueur SFD
                                        // Routage avant appel fct
        "",
        0,                    // Lng Routage avant appel fct
        "M",                          // Type fct = module
        (void *)NULL,                 // Ptr fct métier
        "EIVTWE20",                  // Nom module métier
        "R",                  // Sens message après fct
        "N",                          // Obligation retour
        "",                  // Nouveau SFD
        0,                    // Longueur Nouveau SFD
        "",                  // Type de communication
        "",                  // Nom communication
        0,                    // Longueur nom communication
                                      // Paramètres communication
        "",
        0,                    // Lng param communication
        1,                            // Calcul intégrité
        1,                            // Calcul signature
        0,                            // Confidentialité
        0                             // Compression
    },
    {
    //
    // Fonction FCTE:PARAM
    //
        ETA_PTB_OCC,                  // Etat = Occupe
        "", 0,                        // SFO
        "FCTE:PARAM",                    // SFD
        10,                      // Longueur SFD
                                        // Routage avant appel fct
        "",
        0,                    // Lng Routage avant appel fct
        "M",                          // Type fct = module
        (void *)NULL,                 // Ptr fct métier
        "EIVTWE27",                  // Nom module métier
        "R",                  // Sens message après fct
        "N",                          // Obligation retour
        "",                  // Nouveau SFD
        0,                    // Longueur Nouveau SFD
        "",                  // Type de communication
        "",                  // Nom communication
        0,                    // Longueur nom communication
                                      // Paramètres communication
        "",
        0,                    // Lng param communication
        1,                            // Calcul intégrité
        1,                            // Calcul signature
        0,                            // Confidentialité
        0                             // Compression
    },
    {
    //
    // Fonction FCTE:REVERSE
    //
        ETA_PTB_OCC,                  // Etat = Occupe
        "", 0,                        // SFO
        "FCTE:REVERSE",                    // SFD
        12,                      // Longueur SFD
                                        // Routage avant appel fct
        "",
        0,                    // Lng Routage avant appel fct
        "M",                          // Type fct = module
        (void *)NULL,                 // Ptr fct métier
        "EIVTWE30",                  // Nom module métier
        "R",                  // Sens message après fct
        "N",                          // Obligation retour
        "",                  // Nouveau SFD
        0,                    // Longueur Nouveau SFD
        "",                  // Type de communication
        "",                  // Nom communication
        0,                    // Longueur nom communication
                                      // Paramètres communication
        "",
        0,                    // Lng param communication
        1,                            // Calcul intégrité
        1,                            // Calcul signature
        0,                            // Confidentialité
        0                             // Compression
    },
    {
    //
    // Fonction FCTE:ACTIVITE
    //
        ETA_PTB_OCC,                  // Etat = Occupe
        "", 0,                        // SFO
        "FCTE:ACTIVITE",                    // SFD
        13,                      // Longueur SFD
                                        // Routage avant appel fct
        "",
        0,                    // Lng Routage avant appel fct
        "M",                          // Type fct = module
        (void *)NULL,                 // Ptr fct métier
        "EIVTWE31",                  // Nom module métier
        "R",                  // Sens message après fct
        "N",                          // Obligation retour
        "",                  // Nouveau SFD
        0,                    // Longueur Nouveau SFD
        "",                  // Type de communication
        "",                  // Nom communication
        0,                    // Longueur nom communication
                                      // Paramètres communication
        "",
        0,                    // Lng param communication
        1,                            // Calcul intégrité
        1,                            // Calcul signature
        0,                            // Confidentialité
        0                             // Compression
    },
    {
    //
    // Fonction FCTE:IMPORTS ART
    //
        ETA_PTB_OCC,                  // Etat = Occupe
        "", 0,                        // SFO
        "FCTE:IMPORTS ART",                    // SFD
        16,                      // Longueur SFD
                                        // Routage avant appel fct
        "",
        0,                    // Lng Routage avant appel fct
        "M",                          // Type fct = module
        (void *)NULL,                 // Ptr fct métier
        "EIVTWE18",                  // Nom module métier
        "R",                  // Sens message après fct
        "N",                          // Obligation retour
        "",                  // Nouveau SFD
        0,                    // Longueur Nouveau SFD
        "",                  // Type de communication
        "",                  // Nom communication
        0,                    // Longueur nom communication
                                      // Paramètres communication
        "",
        0,                    // Lng param communication
        1,                            // Calcul intégrité
        1,                            // Calcul signature
        0,                            // Confidentialité
        0                             // Compression
    },
    {
    //
    // Fonction FCTE:AR2
    //
        ETA_PTB_OCC,                  // Etat = Occupe
        "", 0,                        // SFO
        "FCTE:AR2",                    // SFD
        8,                      // Longueur SFD
                                        // Routage avant appel fct
        "",
        0,                    // Lng Routage avant appel fct
        "M",                          // Type fct = module
        (void *)NULL,                 // Ptr fct métier
        "EIVTWE18",                  // Nom module métier
        "R",                  // Sens message après fct
        "N",                          // Obligation retour
        "",                  // Nouveau SFD
        0,                    // Longueur Nouveau SFD
        "",                  // Type de communication
        "",                  // Nom communication
        0,                    // Longueur nom communication
                                      // Paramètres communication
        "",
        0,                    // Lng param communication
        1,                            // Calcul intégrité
        1,                            // Calcul signature
        0,                            // Confidentialité
        0                             // Compression
    },
    {
    //
    // Fonction FCTE:RAPPRO
    //
        ETA_PTB_OCC,                  // Etat = Occupe
        "", 0,                        // SFO
        "FCTE:RAPPRO",                    // SFD
        11,                      // Longueur SFD
                                        // Routage avant appel fct
        "",
        0,                    // Lng Routage avant appel fct
        "M",                          // Type fct = module
        (void *)NULL,                 // Ptr fct métier
        "EIVTWE32",                  // Nom module métier
        "R",                  // Sens message après fct
        "N",                          // Obligation retour
        "",                  // Nouveau SFD
        0,                    // Longueur Nouveau SFD
        "",                  // Type de communication
        "",                  // Nom communication
        0,                    // Longueur nom communication
                                      // Paramètres communication
        "",
        0,                    // Lng param communication
        1,                            // Calcul intégrité
        1,                            // Calcul signature
        0,                            // Confidentialité
        0                             // Compression
    },
    {
    //
    // Fonction FCTE:CONSOBANGUI
    //
        ETA_PTB_OCC,                  // Etat = Occupe
        "", 0,                        // SFO
        "FCTE:CONSOBANGUI",                    // SFD
        16,                      // Longueur SFD
                                        // Routage avant appel fct
        "",
        0,                    // Lng Routage avant appel fct
        "M",                          // Type fct = module
        (void *)NULL,                 // Ptr fct métier
        "EIVTWE32",                  // Nom module métier
        "R",                  // Sens message après fct
        "N",                          // Obligation retour
        "",                  // Nouveau SFD
        0,                    // Longueur Nouveau SFD
        "",                  // Type de communication
        "",                  // Nom communication
        0,                    // Longueur nom communication
                                      // Paramètres communication
        "",
        0,                    // Lng param communication
        1,                            // Calcul intégrité
        1,                            // Calcul signature
        0,                            // Confidentialité
        0                             // Compression
    },
    {
    //
    // Fonction SAD-EivAddIvcFnc
    //
        ETA_PTB_OCC,                  // Etat = Occupe
        "", 0,                        // SFO
        "SAD-EivAddIvcFnc",                    // SFD
        16,                      // Longueur SFD
                                        // Routage avant appel fct
        "",
        0,                    // Lng Routage avant appel fct
        "M",                          // Type fct = module
        (void *)NULL,                 // Ptr fct métier
        "EIVTWE33",                  // Nom module métier
        "R",                  // Sens message après fct
        "N",                          // Obligation retour
        "",                  // Nouveau SFD
        0,                    // Longueur Nouveau SFD
        "",                  // Type de communication
        "",                  // Nom communication
        0,                    // Longueur nom communication
                                      // Paramètres communication
        "",
        0,                    // Lng param communication
        1,                            // Calcul intégrité
        1,                            // Calcul signature
        0,                            // Confidentialité
        0                             // Compression
    },
// SKELS(ZTMCSPC2)
//---------------------------------------------------------------------
    //
    // Fonction PING
    //
    {
        ETA_PTB_OCC,               // Etat = Occupe
        "", 0,                     // SFO
        TSINAME""TSINAME, 16,      // SFD service fonction destination
        "", 0,                     // RTG routage ALLER avant appel fct
        "F",                       // Type fct = Fonction
        S_D_PING,                  // FCT fonction service appelee
        "",                        // Nom module métier
        "R",                       // Sens message après fct
        "N",                       // Obligation retour
        "", 0,                     // Nouveau SFD
        "",                        // Type de communication
        "", 0,                     // Nom communication
        "", 0,                     // Param communication
        1,                         // Calcul intégrité
        1,                         // Calcul signature
        0,                         // Confidentialité
        0                          // Compression
    },
} ;
//
//RPL*26.03.2012*#ifndef __MQI_TRT_CTX
#ifndef __TMCPAL_SUP_OUI
static TMCPAL params_psb =
{
    __NIVEAUTRACE,         // niv_tra : Niveau de trace
    PSBNAME,               // psb_nom : Nom du PSB
    TSINAME,               // tsi_nom : Nom de la tsi
    MQQTSI,                // mqqtsi  : Nom de la queue MQ
    sizeof(MQQTSI)-1,      // lmqqtsi
    (void *)&tbl_pcb,      // tbl_pcb : Ptr vers table PCB
    __NBR_FCT+1,           // nbfct   : Nb de fcts métier
    TAB_fctmet,            // fctmet  : table SFO/SFD
    TBL_FCT_PFCT,          // Format table SFD
 #ifdef __RMI_TRT_OUI
    TOP_REF_RTG_O          // Top utilisation referentiel RTG/LOC
 #endif
 #ifndef __RMI_TRT_OUI
    TOP_REF_RTG_N          // Top non utilisation ref. RTG/LOC
 #endif
} ;
#endif
//
//RPL*26.03.2012*#ifdef __MQI_TRT_CTX
#ifdef __TMCPAL_SUP_OUI
static TMCPAL params_psb =
{
    __NIVEAUTRACE,         // niv_tra : Niveau de trace
    PSBNAME,               // psb_nom : Nom du PSB
    TSINAME,               // tsi_nom : Nom de la tsi
    MQQTSI,                // mqqtsi  : Nom de la queue MQ
    sizeof(MQQTSI)-1,      // lmqqtsi
    (void *)&tbl_pcb,    // tbl_pcb : Ptr vers table PCB
    __NBR_FCT+1,           // nbfct   : Nb de fcts métier
    TAB_fctmet,            // fctmet  : table SFO/SFD
    TBL_FCT_PFCT,          // Format table SFD
 #ifdef __RMI_TRT_OUI      // Top utilisation referentiel RTG/LOC
    TOP_REF_RTG_O+VAL_ZONE_SUP,
 #endif
 #ifndef __RMI_TRT_OUI     // Top non utilisation ref. RTG/LOC
    TOP_REF_RTG_N+VAL_ZONE_SUP,
 #endif
 //
 // ajout PSB pour utilisation contexte
     VAL_BALISE_DEB,
 #ifdef  __MQI_TRT_CTX
    MDW_CTX_YES,
 #endif
 #ifndef  __MQI_TRT_CTX
   //ADD*DEB*OL*06.09.2012*
   // Si ctx non defini test si msg RAW
   //MDW_CTX_NO,
   #ifdef  __MQI_TRT_RAW
      MDW_CTX_MQ_RAW,
   #endif
   #ifndef  __MQI_TRT_RAW
     #ifdef  __MQI_TRT_RWI
        MDW_CTX_MQ_RWI,
     #endif
      #ifndef  __MQI_TRT_RWI
        MDW_CTX_NO,
      #endif
   #endif
   //ADD*FIN*OL*06.09.2012*
 #endif
 //
 //DEL*DEB*OL*06.09.2012*
 //ADD*DEB*CJ*26.03.2012*
 // Ajout table PCB name
 /*
 #ifdef __TBL_PCB_NOM_OUI
     PCB_NOM_OUI,
     (void *)&tbl_pcb_nom,
 #endif
 #ifndef __TBL_PCB_NOM_OUI
     PCB_NOM_NON,
     (void *)NULL,
 #endif
 */
 //ADD*FIN*CJ*26.03.2012*
 //DEL*FIN*OL*06.09.2012*
 //
     "",
     VAL_BALISE_FIN
} ;
#endif
//
// =================================================================
// Gestion des traces pour debug
// =================================================================
#ifdef __TRACEACTIVE
       //     __DEBUG(nom_fonction,message)
#      define __DEBUG(x,y) \
                printf( PSBNAME"_%s_%s\n", x, y )
       //     __DEBUGN(nom_fonction,message,valeur int)
#      define __DEBUGN(x,y,z) \
                printf( PSBNAME"_%s_%s = %d\n", x, y, z )
       //     __DEBUGS(nom_fonction,message,longueur chaine,chaine)
#      define __DEBUGS(x,y,z,a) \
              printf( PSBNAME"_%s_%s = %.*s\n", x, y, z, a )
#endif // ifdef __TRACEACTIVE
//
// -------------------------------------------------------------------
//  Fonction de maj des pointeurs vers les bases IMS
// -------------------------------------------------------------------
static void SET_baseims()
{
    int i_pcb ;                          // Indice PCB
    // Maj nombre total PCB
    tbl_pcb.nbr_pcb = __PSB_NBR_PCB ;
    //
    // Maj IOPCB Middleware = NULL : maj par moteur TMC lors INIT
    //tbl_pcb.ptr_pcb[0] = (DB_PCB_GEN *)GET_iopcb(); // Ptr IOPCB MIDW
    tbl_pcb.ptr_pcb[0] = (DB_PCB_GEN *)NULL ;
    //
    // Boucle maj pointeur PCB
    for ( i_pcb=1 ; i_pcb < __PSB_NBR_PCB ; i_pcb++ )
       tbl_pcb.ptr_pcb[i_pcb] = (DB_PCB_GEN *)(__pcblist)[i_pcb];
    //
    //ADD*DEB*CJ*26.03.2012*
    // Update table PCB NOM
   #ifdef __TBL_PCB_NOM_OUI
    tbl_pcb_nom.nbr_pcb = __PSB_NBR_PCB ;
// SKELS(ZTMCSPC5) - Update
//---------------------------------------------------------------------
// 26.03.2012 - CJ - Mise en place table PCB
//   - CREATION ZTMCSPC5 pour gestion TBL_PCBNOM
//   - RPL '__MQI_TRT_CTX' par  '__TMCPAL_SUP_OUI'
//---------------------------------------------------------------------
   #endif // Fin table PCB NOM
   // Fin fonction SET_baseims
}
//
/*********************************************************************
 *                                                                   *
 *  MAIN - point entree PSB                                          *
 *                                                                   *
 *********************************************************************/
int main()
{
    int fct_moteur ;
#ifdef __TRACEACTIVE
   char* libfct = "main" ;
   time_t tme ;
   struct tm *time1, *time2 ;
   //
   if ( niv_trc )
   {
     time(&tme) ;
     time1 = localtime(&tme) ;
     __DEBUG ( libfct, "Entree dans PSB") ;
   }
#endif
    // ----------------------
    // Maj pointeur bases IMS
    // ----------------------
    SET_baseims();
    // ----------------
    // Appel Moteur TMC
    // ----------------
   #ifdef __RMI_TRT_NON
    fct_moteur = FCT_START ;
   #endif
   #ifdef __RMI_TRT_OUI
    fct_moteur = FCT_START_TMC_COB ;
   #endif
    zcallpgm( MTR_TMC_LOAD, &fct_moteur, (void *)&params_psb );
#ifdef __TRACEACTIVE
 if ( niv_trc )
 {
   time(&tme) ;
   time2 = localtime(&tme) ;
   printf( PSBNAME"_ DEBUT = %d:%d:%d / FIN = %d:%d:%d\n",
           time1->tm_hour, time1->tm_min, time1->tm_sec,
           time2->tm_hour, time2->tm_min, time2->tm_sec ) ;
   __DEBUG ( libfct, "Sortie PSB") ;
 }
#endif
    return(0) ;
}
//
/*********************************************************************
 * DESCRIPTION : S_D_PING - Service PING                             *
 *               Fonction reservee pour la surveillance systeme      *
 *********************************************************************/
static void S_D_PING()
{
#ifdef __TRACEACTIVE
    char* libfct = "S_D_PING" ;
    __DEBUG( libfct, "Ping PSB" ) ;
#endif
}
